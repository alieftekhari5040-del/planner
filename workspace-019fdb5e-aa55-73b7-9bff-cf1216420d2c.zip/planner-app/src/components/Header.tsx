import React from 'react';
import { 
  Printer, 
  Sparkles, 
  RotateCcw, 
  Volume2, 
  VolumeX, 
  Calendar, 
  Timer, 
  FileJson,
  CalendarDays
} from 'lucide-react';

interface HeaderProps {
  onPrint: () => void;
  onReset: () => void;
  onOpenPomodoro: () => void;
  onOpenHistory: () => void;
  onOpenCalendarModal: () => void;
  onOpenTemplates: () => void;
  onExportJSON: () => void;
  onLoadDemoData: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
  completionPercentage: number;
}

export const Header: React.FC<HeaderProps> = ({
  onPrint,
  onReset,
  onOpenPomodoro,
  onOpenHistory,
  onOpenCalendarModal,
  onOpenTemplates,
  onExportJSON,
  onLoadDemoData,
  soundEnabled,
  onToggleSound,
  completionPercentage,
}) => {
  return (
    <header className="w-full mb-6">
      {/* Interactive Controls Bar (Top Toolbar) */}
      <div className="no-print flex flex-wrap items-center justify-between gap-3 p-3.5 mb-6 rounded-2xl bg-[#0d0926]/90 border border-purple-500/30 backdrop-blur-md shadow-lg shadow-purple-950/40">
        <div className="flex items-center gap-2 flex-wrap">
          {/* Quick Info & Completion Progress */}
          <div className="flex items-center gap-3 px-3 py-1.5 rounded-xl bg-purple-950/50 border border-purple-500/20">
            <div className="relative w-8 h-8 flex items-center justify-center">
              <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                <path
                  className="text-purple-950"
                  strokeWidth="3.5"
                  stroke="currentColor"
                  fill="none"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
                <path
                  className="text-purple-400 transition-all duration-500"
                  strokeDasharray={`${completionPercentage}, 100`}
                  strokeWidth="3.5"
                  strokeLinecap="round"
                  stroke="currentColor"
                  fill="none"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
              </svg>
              <span className="absolute text-[10px] font-bold text-purple-200">
                {Math.round(completionPercentage)}%
              </span>
            </div>
            <div className="text-right">
              <div className="text-xs font-semibold text-purple-200">پیشرفت روزانه</div>
              <div className="text-[11px] text-purple-400/80">
                {completionPercentage === 100 ? '🎉 تکمیل کامل روز!' : `${Math.round(completionPercentage)} درصد انجام شده`}
              </div>
            </div>
          </div>

          {/* Pomodoro Timer button */}
          <button
            onClick={onOpenPomodoro}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-rose-900/60 to-purple-900/60 hover:from-rose-800/80 hover:to-purple-800/80 border border-rose-500/30 text-rose-200 hover:text-white text-xs font-medium transition shadow-sm hover:shadow-rose-900/30 cursor-pointer"
            title="تایمر تمرکز پومودورو"
          >
            <Timer className="w-4 h-4 text-rose-400 animate-pulse" />
            <span>تایمر تمرکز (Pomodoro)</span>
          </button>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Quick Demo Mode Trigger Button */}
          <button
            onClick={onLoadDemoData}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-600/70 to-orange-600/70 hover:from-amber-500 hover:to-orange-500 border border-amber-400/40 text-white text-xs font-bold transition shadow-sm cursor-pointer"
            title="بارگذاری نمونه کامل آزمایشی"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-200" />
            <span>⚡ نمونه آزمایشی</span>
          </button>

          {/* Month Calendar Drawer & Day Navigator */}
          <button
            onClick={onOpenCalendarModal}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-purple-900/40 hover:bg-purple-800/60 border border-purple-500/30 text-purple-200 text-xs font-medium transition cursor-pointer"
            title="تقویم ماهانه و جابجایی بین روزها"
          >
            <CalendarDays className="w-3.5 h-3.5 text-purple-300" />
            <span>تقویم ماهانه</span>
          </button>

          {/* Templates */}
          <button
            onClick={onOpenTemplates}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-purple-900/30 hover:bg-purple-800/50 border border-purple-500/20 text-purple-200 text-xs font-medium transition cursor-pointer"
            title="قالب‌های آماده روزانه"
          >
            <Calendar className="w-3.5 h-3.5 text-amber-400" />
            <span>قالب‌ها</span>
          </button>

          {/* History */}
          <button
            onClick={onOpenHistory}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-purple-900/30 hover:bg-purple-800/50 border border-purple-500/20 text-purple-200 text-xs font-medium transition cursor-pointer"
            title="تاریخچه روزهای ثبت شده"
          >
            <span>تاریخچه</span>
          </button>

          {/* Backup JSON */}
          <button
            onClick={onExportJSON}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-purple-900/30 hover:bg-purple-800/50 border border-purple-500/20 text-purple-200 text-xs font-medium transition cursor-pointer"
            title="دانلود بک‌آپ JSON"
          >
            <FileJson className="w-3.5 h-3.5 text-purple-300" />
            <span>بک‌آپ</span>
          </button>

          {/* Sound Toggle */}
          <button
            onClick={onToggleSound}
            className={`p-1.5 rounded-lg border transition cursor-pointer ${
              soundEnabled
                ? 'bg-purple-900/40 border-purple-500/40 text-purple-300'
                : 'bg-zinc-900/50 border-zinc-700/50 text-zinc-500'
            }`}
            title={soundEnabled ? 'صدا روشن است' : 'صدا خاموش است'}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          {/* Print / PDF */}
          <button
            onClick={onPrint}
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-purple-600/80 hover:bg-purple-500 border border-purple-400/40 text-white text-xs font-semibold shadow-md shadow-purple-950/50 transition cursor-pointer"
            title="چاپ یا ذخیره PDF"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>چاپ / PDF</span>
          </button>

          {/* Reset */}
          <button
            onClick={onReset}
            className="p-1.5 rounded-lg bg-purple-900/20 hover:bg-red-950/40 border border-purple-500/20 hover:border-red-500/40 text-purple-300 hover:text-red-300 text-xs transition cursor-pointer"
            title="پاکسازی روز جاری"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Poster Header (Faithful 1:1 reproduction of the image header) */}
      <div className="flex items-start justify-between px-2 pt-2 pb-3">
        {/* Right side in Persian (Left side visually in RTL): Title & Subtitle */}
        <div className="text-right">
          <h1 className="text-4xl md:text-5xl font-black tracking-tight text-white drop-shadow-[0_0_20px_rgba(168,85,247,0.75)] font-sans">
            برنامه‌ی روزانه
          </h1>
          <p className="mt-1.5 text-sm md:text-base font-normal text-purple-300/80 tracking-wide">
            هر روز یک قدم جلوتر
          </p>
        </div>

        {/* Left side in Persian (Right side visually in RTL): THE ASCENT BLUEPRINT Branding */}
        <div className="flex items-center gap-3.5 text-left direction-ltr" style={{ direction: 'ltr' }}>
          <div>
            <div className="text-xs md:text-sm font-black tracking-[0.25em] text-white/90 uppercase font-mono">
              THE ASCENT
            </div>
            <div className="text-[10px] md:text-xs font-bold tracking-[0.3em] text-purple-300/80 uppercase font-mono">
              BLUEPRINT
            </div>
          </div>
          {/* Pill / Capsule 3-bar icon matching the top right logo */}
          <div className="flex items-center gap-1.5 pl-1">
            <div className="w-2.5 h-9 rounded-full bg-gradient-to-b from-white via-purple-200 to-purple-400 shadow-[0_0_12px_rgba(255,255,255,0.7)]" />
            <div className="w-2.5 h-9 rounded-full bg-gradient-to-b from-white via-purple-200 to-purple-400 shadow-[0_0_12px_rgba(255,255,255,0.7)]" />
            <div className="w-2.5 h-9 rounded-full bg-gradient-to-b from-white via-purple-200 to-purple-400 shadow-[0_0_12px_rgba(255,255,255,0.7)]" />
          </div>
        </div>
      </div>
    </header>
  );
};
