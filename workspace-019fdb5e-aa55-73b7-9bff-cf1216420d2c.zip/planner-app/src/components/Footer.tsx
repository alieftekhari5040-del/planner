import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="w-full mt-6 pt-4 pb-2 border-t border-purple-500/20 flex flex-wrap items-center justify-between text-xs text-purple-300/70">
      {/* Right side in Persian (Left in RTL): روز صفر تا قله */}
      <div className="font-medium tracking-wide">
        روز صفر تا قله
      </div>

      {/* Left side in Persian (Right in RTL): ● THE ASCENT BLUEPRINT - DAILY */}
      <div className="flex items-center gap-2 font-mono tracking-wider font-bold direction-ltr" style={{ direction: 'ltr' }}>
        <span className="w-2 h-2 rounded-full bg-rose-500 shadow-[0_0_8px_rgba(244,63,94,1)] animate-pulse" />
        <span className="text-white/90">THE ASCENT BLUEPRINT</span>
        <span className="text-purple-400">- DAILY</span>
      </div>
    </footer>
  );
};
