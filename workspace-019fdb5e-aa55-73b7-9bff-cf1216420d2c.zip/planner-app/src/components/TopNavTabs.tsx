import React from 'react';
import { Calendar, Flame, BarChart3 } from 'lucide-react';

export type MainTabType = 'planner' | 'habits' | 'analytics';

interface TopNavTabsProps {
  activeTab: MainTabType;
  onChangeTab: (tab: MainTabType) => void;
}

export const TopNavTabs: React.FC<TopNavTabsProps> = ({ activeTab, onChangeTab }) => {
  return (
    <div className="no-print w-full flex items-center justify-center mb-6">
      <div className="flex flex-wrap items-center justify-center gap-2 p-1.5 rounded-2xl md:rounded-3xl bg-[#0e092c]/90 border border-purple-500/40 backdrop-blur-xl shadow-xl shadow-purple-950/50">
        {/* Tab 1: Daily Planner (Original Blueprint) */}
        <button
          onClick={() => onChangeTab('planner')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl md:rounded-2xl text-xs sm:text-sm font-bold transition-all duration-200 cursor-pointer ${
            activeTab === 'planner'
              ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-[0_0_20px_rgba(168,85,247,0.7)] scale-105 border border-purple-300'
              : 'text-purple-300 hover:text-white hover:bg-purple-950/60'
          }`}
        >
          <Calendar className="w-4 h-4 text-purple-200" />
          <span>برنامه‌ریزی روزانه (The Blueprint)</span>
        </button>

        {/* Tab 2: Pro Habit OS (Dedicated Habit Tracker) */}
        <button
          onClick={() => onChangeTab('habits')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl md:rounded-2xl text-xs sm:text-sm font-bold transition-all duration-200 cursor-pointer ${
            activeTab === 'habits'
              ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-[0_0_20px_rgba(168,85,247,0.7)] scale-105 border border-purple-300'
              : 'text-purple-300 hover:text-white hover:bg-purple-950/60'
          }`}
        >
          <Flame className="w-4 h-4 text-amber-400 animate-pulse" />
          <span>ردیاب حرفه‌ای عادت‌ها (Habit OS)</span>
          <span className="hidden sm:inline-block px-1.5 py-0.5 rounded-full bg-rose-500/80 text-[10px] text-white">
            ویژه 🔥
          </span>
        </button>

        {/* Tab 3: Analytics & Insights */}
        <button
          onClick={() => onChangeTab('analytics')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl md:rounded-2xl text-xs sm:text-sm font-bold transition-all duration-200 cursor-pointer ${
            activeTab === 'analytics'
              ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-[0_0_20px_rgba(168,85,247,0.7)] scale-105 border border-purple-300'
              : 'text-purple-300 hover:text-white hover:bg-purple-950/60'
          }`}
        >
          <BarChart3 className="w-4 h-4 text-cyan-300" />
          <span>داشبورد و آمار (Analytics)</span>
        </button>
      </div>
    </div>
  );
};
