import React, { useState, useEffect, useMemo, useRef } from 'react';
import confetti from 'canvas-confetti';
import type { 
  DailyPlannerData, 
  PriorityItem, 
  GoalItem, 
  RoutineItem, 
  ScheduleItem 
} from './types/planner';
import type { Habit } from './types/habits';
import { 
  getTodayJalali, 
  getDateKey, 
  formatPersianDateString,
  addDaysToJalali 
} from './utils/jalali';
import { 
  loadPlannerData, 
  savePlannerData, 
  createDefaultDayData 
} from './utils/storage';
import { loadHabits, saveHabits } from './utils/habitStorage';
import { getDemoPlannerData } from './utils/demoData';
import { playTickSound, playSuccessSound } from './utils/audio';

import { TopNavTabs } from './components/TopNavTabs';
import type { MainTabType } from './components/TopNavTabs';
import { Header } from './components/Header';
import { DateSection } from './components/DateSection';
import { PrioritiesCard } from './components/PrioritiesCard';
import { GoalsCard } from './components/GoalsCard';
import { RoutinesCard } from './components/RoutinesCard';
import { ScheduleCard } from './components/ScheduleCard';
import { LessonsCard } from './components/LessonsCard';
import { Footer } from './components/Footer';

import { HabitTrackerPage } from './components/HabitTracker/HabitTrackerPage';
import { AnalyticsPage } from './components/Analytics/AnalyticsPage';

import { CalendarModal } from './components/CalendarModal';
import { PomodoroModal } from './components/PomodoroModal';
import { TemplatesModal } from './components/TemplatesModal';
import { HistoryModal } from './components/HistoryModal';

export const App: React.FC = () => {
  // Navigation tab
  const [activeTab, setActiveTab] = useState<MainTabType>('planner');

  // Initialize date
  const todayInfo = useMemo(() => getTodayJalali(), []);
  const [currentJy, setCurrentJy] = useState(todayInfo.jy);
  const [currentJm, setCurrentJm] = useState(todayInfo.jm);
  const [currentJd, setCurrentJd] = useState(todayInfo.jd);
  const [currentDayName, setCurrentDayName] = useState(todayInfo.dayName);

  // Active planner date key
  const dateKey = useMemo(() => getDateKey(currentJy, currentJm, currentJd), [currentJy, currentJm, currentJd]);
  
  // Track active key to prevent save race conditions
  const isLoadedRef = useRef(false);

  const [plannerData, setPlannerData] = useState<DailyPlannerData>(() => {
    return loadPlannerData(dateKey, createDefaultDayData(currentJy, currentJm, currentJd, currentDayName));
  });

  // Habit Tracker state
  const [habits, setHabits] = useState<Habit[]>(() => loadHabits());

  // UI state
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  const [isPomodoroOpen, setIsPomodoroOpen] = useState(false);
  const [isTemplatesOpen, setIsTemplatesOpen] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);

  // Load planner data safely whenever dateKey changes
  useEffect(() => {
    isLoadedRef.current = false;
    const loaded = loadPlannerData(dateKey, createDefaultDayData(currentJy, currentJm, currentJd, currentDayName));
    setPlannerData(loaded);
    setTimeout(() => {
      isLoadedRef.current = true;
    }, 50);
  }, [dateKey, currentJy, currentJm, currentJd, currentDayName]);

  // Auto-save safely whenever plannerData updates
  useEffect(() => {
    if (plannerData && plannerData.dateKey === dateKey && isLoadedRef.current) {
      savePlannerData(plannerData);
    }
  }, [plannerData, dateKey]);

  // Auto-save habits whenever habits list updates
  useEffect(() => {
    if (habits) {
      saveHabits(habits);
    }
  }, [habits]);

  // Completion calculation
  const completionStats = useMemo(() => {
    let total = 0;
    let completed = 0;

    plannerData.priorities?.forEach((p) => {
      if (p.text.trim()) {
        total++;
        if (p.completed) completed++;
      }
    });

    plannerData.routines?.forEach((r) => {
      total++;
      if (r.completed) completed++;
    });

    plannerData.schedule?.forEach((s) => {
      if (s.task.trim()) {
        total++;
        if (s.completed) completed++;
      }
    });

    const percent = total > 0 ? (completed / total) * 100 : 0;
    return { total, completed, percent };
  }, [plannerData]);

  // Trigger celebration confetti when hitting 100%
  useEffect(() => {
    if (completionStats.percent === 100 && completionStats.total >= 4) {
      playSuccessSound(soundEnabled);
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#a855f7', '#ec4899', '#3b82f6', '#10b981', '#f59e0b']
        });
      } catch {
        // ignore confetti errors
      }
    }
  }, [completionStats.percent, completionStats.total, soundEnabled]);

  // Handlers
  const handleSelectDayOfWeek = (day: string) => {
    playTickSound(soundEnabled);
    setPlannerData((prev) => ({ ...prev, selectedDayOfWeek: day }));
  };

  const handleChangeDateText = (text: string) => {
    setPlannerData((prev) => ({ ...prev, customDateText: text }));
  };

  const handlePreviousDay = () => {
    playTickSound(soundEnabled);
    const target = addDaysToJalali(currentJy, currentJm, currentJd, -1);
    setCurrentJy(target.jy);
    setCurrentJm(target.jm);
    setCurrentJd(target.jd);
    setCurrentDayName(target.dayName);
  };

  const handleNextDay = () => {
    playTickSound(soundEnabled);
    const target = addDaysToJalali(currentJy, currentJm, currentJd, 1);
    setCurrentJy(target.jy);
    setCurrentJm(target.jm);
    setCurrentJd(target.jd);
    setCurrentDayName(target.dayName);
  };

  const handleGoToToday = () => {
    playTickSound(soundEnabled);
    const t = getTodayJalali();
    setCurrentJy(t.jy);
    setCurrentJm(t.jm);
    setCurrentJd(t.jd);
    setCurrentDayName(t.dayName);
  };

  const handleSelectFromCalendar = (jy: number, jm: number, jd: number, _dayName: string) => {
    playTickSound(soundEnabled);
    const target = addDaysToJalali(jy, jm, jd, 0);
    setCurrentJy(target.jy);
    setCurrentJm(target.jm);
    setCurrentJd(target.jd);
    setCurrentDayName(target.dayName);
    const formatted = formatPersianDateString(target.jy, target.jm, target.jd);
    setPlannerData((prev) => ({
      ...prev,
      customDateText: formatted,
      selectedDayOfWeek: target.dayName
    }));
  };

  const handlePriorityToggle = (id: string) => {
    playTickSound(soundEnabled);
    setPlannerData((prev) => ({
      ...prev,
      priorities: prev.priorities.map((item) =>
        item.id === id ? { ...item, completed: !item.completed } : item
      ),
    }));
  };

  const handleGoalToggle = (id: string) => {
    playTickSound(soundEnabled);
    setPlannerData((prev) => ({
      ...prev,
      goals: prev.goals.map((item) =>
        item.id === id ? { ...item, completed: !item.completed } : item
      ),
    }));
  };

  const handleRoutineToggle = (id: string) => {
    playTickSound(soundEnabled);
    setPlannerData((prev) => ({
      ...prev,
      routines: prev.routines.map((item) =>
        item.id === id ? { ...item, completed: !item.completed } : item
      ),
    }));
  };

  const handleScheduleToggle = (id: string) => {
    playTickSound(soundEnabled);
    setPlannerData((prev) => ({
      ...prev,
      schedule: prev.schedule.map((item) =>
        item.id === id ? { ...item, completed: !item.completed } : item
      ),
    }));
  };

  const handleApplyPresetSchedule = () => {
    playTickSound(soundEnabled);
    const smartTasks: ScheduleItem[] = [
      { id: 's-1', task: 'بیدارباش، نوشیدن آب و روتین صبحگاهی', completed: false, category: 'routine' },
      { id: 's-2', task: 'صبحانه سالم و آماده‌سازی محیط کار', completed: false, category: 'routine' },
      { id: 's-3', task: 'بلاک کار عمیق ۱ (سخت‌ترین تسک فنی روز)', completed: false, category: 'work' },
      { id: 's-4', task: 'استراحت فعال، چای و کشش عضلات', completed: false, category: 'rest' },
      { id: 's-5', task: 'بلاک کار عمیق ۲ (توسعه فیچرهای اصلی پروژه)', completed: false, category: 'work' },
      { id: 's-6', task: 'ناهار سبک و استراحت کوتاه بدون صفحه نمایش', completed: false, category: 'rest' },
      { id: 's-7', task: 'پاسخ به ایمیل‌ها، هماهنگی‌ها و جلسات کوتاه', completed: false, category: 'personal' },
      { id: 's-8', task: 'مطالعه تخصصی و یادگیری دوره جدید', completed: false, category: 'study' },
      { id: 's-9', task: 'تمرین بدنسازی / پیاده‌روی هوازی', completed: false, category: 'workout' },
      { id: 's-10', task: 'شام و وقت با کیفیت با خانواده و دوستان', completed: false, category: 'personal' },
      { id: 's-11', task: 'مرور درس‌های امروز و برنامه‌ریزی فردا', completed: false, category: 'routine' },
      { id: 's-12', task: 'مطالعه کتاب و خاموشی صفحات نمایش', completed: false, category: 'rest' },
      { id: 's-13', task: 'خواب عمیق و بازسازی انرژی برای فردا', completed: false, category: 'rest' },
      { id: 's-14', task: 'مدیتیشن و تنفس عمیق قبل خواب', completed: false, category: 'routine' },
    ];
    setPlannerData((prev) => ({ ...prev, schedule: smartTasks }));
  };

  const handleApplyTemplate = (template: Partial<DailyPlannerData>) => {
    playSuccessSound(soundEnabled);
    setPlannerData((prev) => ({
      ...prev,
      ...template,
      priorities: (template.priorities as PriorityItem[]) || prev.priorities,
      goals: (template.goals as GoalItem[]) || prev.goals,
      routines: (template.routines as RoutineItem[]) || prev.routines,
    }));
  };

  const handleLoadDemoData = () => {
    playSuccessSound(soundEnabled);
    const demoData = getDemoPlannerData();
    setPlannerData(demoData);
    setActiveTab('planner');
  };

  const handleResetDay = () => {
    if (window.confirm('آیا از ریست کردن و پاکسازی اطلاعات امروز مطمئن هستید؟')) {
      playTickSound(soundEnabled);
      const fresh = createDefaultDayData(currentJy, currentJm, currentJd, currentDayName);
      setPlannerData(fresh);
    }
  };

  const handlePrint = () => {
    playTickSound(soundEnabled);
    window.print();
  };

  const handleExportJSON = () => {
    const backupObject = {
      planner: plannerData,
      habits: habits,
      version: '2.0.0',
      exportedAt: new Date().toISOString(),
    };
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(backupObject, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `ascent-backup-${plannerData.dateKey}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleSelectHistoryDate = (dKey: string) => {
    const parts = dKey.split('-');
    if (parts.length === 3) {
      const jy = parseInt(parts[0], 10);
      const jm = parseInt(parts[1], 10);
      const jd = parseInt(parts[2], 10);
      const target = addDaysToJalali(jy, jm, jd, 0);
      setCurrentJy(target.jy);
      setCurrentJm(target.jm);
      setCurrentJd(target.jd);
      setCurrentDayName(target.dayName);
    }
  };

  return (
    <div className="min-h-screen bg-[#070514] text-purple-100 flex flex-col items-center justify-start p-3 sm:p-6 md:p-8 selection:bg-purple-500 selection:text-white relative">
      {/* Dynamic Background Cyber Glow Orbs */}
      <div className="fixed top-10 right-10 w-96 h-96 bg-purple-700/10 rounded-full blur-3xl pointer-events-none" />
      <div className="fixed bottom-10 left-10 w-96 h-96 bg-indigo-700/10 rounded-full blur-3xl pointer-events-none" />

      {/* Top Navigation Tabs */}
      <TopNavTabs activeTab={activeTab} onChangeTab={setActiveTab} />

      {/* Main Container mirroring the exact aspect ratio & glowing borders */}
      <main className="w-full max-w-5xl rounded-[28px] md:rounded-[36px] border-2 border-purple-500/70 p-4 sm:p-6 md:p-8 bg-[#09061d]/95 backdrop-blur-2xl shadow-[0_0_50px_rgba(139,92,246,0.35),inset_0_0_40px_rgba(139,92,246,0.12)] print-container relative">
        {/* Top Header */}
        <Header
          onPrint={handlePrint}
          onReset={handleResetDay}
          onOpenPomodoro={() => setIsPomodoroOpen(true)}
          onOpenHistory={() => setIsHistoryOpen(true)}
          onOpenCalendarModal={() => setIsCalendarOpen(true)}
          onOpenTemplates={() => setIsTemplatesOpen(true)}
          onExportJSON={handleExportJSON}
          onLoadDemoData={handleLoadDemoData}
          soundEnabled={soundEnabled}
          onToggleSound={() => setSoundEnabled(!soundEnabled)}
          completionPercentage={completionStats.percent}
        />

        {/* TAB 1: DAILY PLANNER (ORIGINAL BLUEPRINT POSTER) */}
        {activeTab === 'planner' && (
          <div className="space-y-6 animate-fadeIn">
            {/* Date & Weekday Ribbon */}
            <DateSection
              selectedDayOfWeek={plannerData.selectedDayOfWeek}
              onSelectDayOfWeek={handleSelectDayOfWeek}
              dateText={plannerData.customDateText}
              onChangeDateText={handleChangeDateText}
              onPreviousDay={handlePreviousDay}
              onNextDay={handleNextDay}
              onGoToToday={handleGoToToday}
            />

            {/* Main Grid: Split into Left Column & Right Column matching the image */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 md:gap-6 items-stretch">
              {/* Left Column in RTL (Stacked 3 Cards): Priorities, Goals, Habits */}
              <div className="lg:col-span-5 flex flex-col gap-5 md:gap-6 justify-between">
                {/* Card 1: اولویت کارها */}
                <PrioritiesCard
                  priorities={plannerData.priorities}
                  onChange={(priorities) => setPlannerData((prev) => ({ ...prev, priorities }))}
                  onItemToggle={handlePriorityToggle}
                />

                {/* Card 2: اهداف امروز */}
                <GoalsCard
                  goals={plannerData.goals}
                  onChange={(goals) => setPlannerData((prev) => ({ ...prev, goals }))}
                  onGoalToggle={handleGoalToggle}
                />

                {/* Card 3: اولویت امروز (عادت‌های اصلی: مطالعه، رشد فردی، بدنسازی) */}
                <RoutinesCard
                  routines={plannerData.routines}
                  onChange={(routines) => setPlannerData((prev) => ({ ...prev, routines }))}
                  onItemToggle={handleRoutineToggle}
                />
              </div>

              {/* Right Column in RTL (Clean 14-row checklist table without hardcoded hours): برنامه‌ی امروز */}
              <div className="lg:col-span-7 flex flex-col">
                <ScheduleCard
                  schedule={plannerData.schedule}
                  onChange={(schedule) => setPlannerData((prev) => ({ ...prev, schedule }))}
                  onItemToggle={handleScheduleToggle}
                  onApplyPresetTasks={handleApplyPresetSchedule}
                />
              </div>
            </div>

            {/* Bottom Full-Width Card: درس‌هایی که امروز گرفتم */}
            <LessonsCard
              lessons={plannerData.lessons}
              onChange={(lessons) => setPlannerData((prev) => ({ ...prev, lessons }))}
            />
          </div>
        )}

        {/* TAB 2: PRO HABIT OS (DEDICATED ADVANCED HABIT TRACKER - MATRIX ONLY) */}
        {activeTab === 'habits' && (
          <div className="animate-fadeIn">
            <HabitTrackerPage
              habits={habits}
              todayKey={dateKey}
              onUpdateHabits={setHabits}
              soundEnabled={soundEnabled}
            />
          </div>
        )}

        {/* TAB 3: ANALYTICS & INSIGHTS */}
        {activeTab === 'analytics' && (
          <div className="animate-fadeIn">
            <AnalyticsPage
              habits={habits}
              plannerData={plannerData}
              todayKey={dateKey}
            />
          </div>
        )}

        {/* Footer */}
        <Footer />
      </main>

      {/* Modals */}
      <CalendarModal
        isOpen={isCalendarOpen}
        onClose={() => setIsCalendarOpen(false)}
        currentJy={currentJy}
        currentJm={currentJm}
        currentJd={currentJd}
        onSelectDate={handleSelectFromCalendar}
      />

      <PomodoroModal
        isOpen={isPomodoroOpen}
        onClose={() => setIsPomodoroOpen(false)}
        soundEnabled={soundEnabled}
      />

      <TemplatesModal
        isOpen={isTemplatesOpen}
        onClose={() => setIsTemplatesOpen(false)}
        onApplyTemplate={handleApplyTemplate}
      />

      <HistoryModal
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        onSelectDate={handleSelectHistoryDate}
        currentDateKey={dateKey}
      />
    </div>
  );
};

export default App;
