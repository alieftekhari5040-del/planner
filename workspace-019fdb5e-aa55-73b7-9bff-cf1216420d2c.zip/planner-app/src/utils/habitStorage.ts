import type { Habit, HabitStats } from '../types/habits';
import { getTodayJalali, getDateKey } from './jalali';

const HABITS_STORAGE_KEY = 'ascent_pro_habits_data_v1';

export function getDefaultHabits(): Habit[] {
  const today = getTodayJalali();
  const todayKey = getDateKey(today.jy, today.jm, today.jd);

  // Generate some realistic past 14 days history so heatmaps and streak counters look alive on first load!
  const generateMockHistory = (completionProbability: number) => {
    const history: Record<string, { completed: boolean; value?: number }> = {};
    for (let i = 28; i >= 0; i--) {
      let d = today.jd - i;
      let m = today.jm;
      let y = today.jy;
      if (d < 1) {
        m = today.jm - 1;
        if (m < 1) {
          m = 12;
          y = today.jy - 1;
        }
        d = 30 + d;
      }
      const k = getDateKey(y, m, d);
      const isDone = Math.random() < completionProbability;
      if (isDone) {
        history[k] = { completed: true, value: 1 };
      }
    }
    return history;
  };

  return [
    {
      id: 'h-water',
      name: 'نوشیدن ۲ لیتر آب روزانه',
      category: 'health',
      icon: '💧',
      color: '#38bdf8', // Neon Sky Blue
      targetType: 'numeric',
      targetValue: 2000,
      unit: 'میلی‌لیتر',
      frequency: 'daily',
      timeOfDay: 'anytime',
      atomicCue: 'بلافاصله بعد از بیدار شدن و قبل از هر وعده غذایی یک لیوان بزرگ آب می‌نوشم.',
      atomicReward: 'احساس شادابی پوست و افزایش تمرکز مغز',
      createdAt: todayKey,
      history: generateMockHistory(0.85),
    },
    {
      id: 'h-reading',
      name: 'مطالعه کتاب تخصصی و رشد فردی',
      category: 'learning',
      icon: '📚',
      color: '#a855f7', // Neon Purple
      targetType: 'timer',
      targetValue: 30,
      unit: 'دقیقه',
      frequency: 'daily',
      timeOfDay: 'evening',
      atomicCue: 'ساعت ۲۱:۰۰ بعد از شام، کتاب را روی میز کنار تخت باز می‌کنم.',
      atomicReward: 'افزایش دانش و آرامش قبل از خواب عمیق',
      createdAt: todayKey,
      history: generateMockHistory(0.75),
    },
    {
      id: 'h-workout',
      name: 'ورزش، باشگاه یا پیاده‌روی سریع',
      category: 'fitness',
      icon: '🏋️‍♂️',
      color: '#f43f5e', // Neon Rose
      targetType: 'timer',
      targetValue: 45,
      unit: 'دقیقه',
      frequency: 'daily',
      timeOfDay: 'afternoon',
      atomicCue: 'ساعت ۱۷:۳۰ لباس ورزشی را می‌پوشم و کفش‌ها را جفت می‌کنم.',
      atomicReward: 'تخلیه استرس کاری و ساخت فیزیک بدنی متناسب',
      createdAt: todayKey,
      history: generateMockHistory(0.7),
    },
    {
      id: 'h-deepwork',
      name: 'بلاک کار عمیق (Deep Work & Code)',
      category: 'productivity',
      icon: '⚡',
      color: '#fbbf24', // Neon Amber
      targetType: 'numeric',
      targetValue: 4,
      unit: 'بلاک ۹۰ دقیقه‌ای',
      frequency: 'weekdays',
      timeOfDay: 'morning',
      atomicCue: 'بستن تمام تب‌های شبکه‌های اجتماعی و روشن کردن حالت فوکوس پومودورو.',
      atomicReward: 'پیشرفت چشمگیر در تسک‌های پیچیده فنی',
      createdAt: todayKey,
      history: generateMockHistory(0.8),
    },
    {
      id: 'h-meditation',
      name: 'مدیتیشن و تنفس عمیق آگاهانه',
      category: 'mind',
      icon: '🧘',
      color: '#34d399', // Neon Emerald
      targetType: 'timer',
      targetValue: 10,
      unit: 'دقیقه',
      frequency: 'daily',
      timeOfDay: 'morning',
      atomicCue: 'صبح‌ها بعد از مرتب کردن تخت، ۵ دقیقه در سکوت چشم‌ها را می‌بندم.',
      atomicReward: 'کاهش اضطراب روزمره و تسلط بر احساسات',
      createdAt: todayKey,
      history: generateMockHistory(0.6),
    },
    {
      id: 'h-sleep',
      name: 'خاموشی صفحات نمایش و خواب قبل ۲۳:۳۰',
      category: 'lifestyle',
      icon: '🌙',
      color: '#818cf8', // Neon Indigo
      targetType: 'boolean',
      targetValue: 1,
      unit: 'بار',
      frequency: 'daily',
      timeOfDay: 'evening',
      atomicCue: 'ساعت ۲۳:۰۰ گوشی را در حالت Sleep Mode در خارج از اتاق خواب قرار می‌دهم.',
      atomicReward: 'بیدار شدن با نشاط بالا در ساعت ۶:۰۰ صبح',
      createdAt: todayKey,
      history: generateMockHistory(0.7),
    }
  ];
}

export function loadHabits(): Habit[] {
  try {
    const raw = localStorage.getItem(HABITS_STORAGE_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (e) {
    console.error('Error loading habits', e);
  }
  const defaultList = getDefaultHabits();
  saveHabits(defaultList);
  return defaultList;
}

export function saveHabits(habits: Habit[]): void {
  try {
    localStorage.setItem(HABITS_STORAGE_KEY, JSON.stringify(habits));
  } catch (e) {
    console.error('Error saving habits', e);
  }
}

// Calculate streaks, completion rates, and strength metrics
export function calculateHabitStats(habit: Habit, _todayKey?: string): HabitStats {
  const history = habit.history || {};
  let totalCompletions = 0;
  
  Object.values(history).forEach((h) => {
    if (h.completed) totalCompletions++;
  });

  // Calculate current streak
  let currentStreak = 0;
  let bestStreak = 0;
  let tempStreak = 0;

  // Inspect past 60 days
  const today = getTodayJalali();
  for (let i = 0; i < 90; i++) {
    let d = today.jd - i;
    let m = today.jm;
    let y = today.jy;
    if (d < 1) {
      m = today.jm - 1;
      if (m < 1) {
        m = 12;
        y = today.jy - 1;
      }
      d = 30 + d;
    }
    const k = getDateKey(y, m, d);
    const entry = history[k];
    const isFreeze = habit.freezeDays?.includes(k);

    if (entry?.completed) {
      tempStreak++;
      if (i === currentStreak) {
        currentStreak = tempStreak;
      }
      if (tempStreak > bestStreak) {
        bestStreak = tempStreak;
      }
    } else if (isFreeze) {
      // Freeze day preserves streak without adding
      continue;
    } else {
      if (i === 0 && !entry?.completed) {
        // Today is not yet checked, don't break yesterday's streak
        continue;
      }
      tempStreak = 0;
    }
  }

  // Monthly completion rate (past 30 days)
  let monthChecked = 0;
  for (let i = 0; i < 30; i++) {
    let d = today.jd - i;
    let m = today.jm;
    let y = today.jy;
    if (d < 1) {
      m = today.jm - 1;
      if (m < 1) {
        m = 12;
        y = today.jy - 1;
      }
      d = 30 + d;
    }
    const k = getDateKey(y, m, d);
    if (history[k]?.completed) monthChecked++;
  }

  const completionRateMonth = Math.round((monthChecked / 30) * 100);
  const completionRateAllTime = totalCompletions > 0 ? Math.min(100, Math.round((totalCompletions / 45) * 100)) : 0;
  const strengthScore = Math.min(100, Math.round(completionRateMonth * 0.7 + Math.min(currentStreak, 30) * 1.0));

  return {
    totalCompletions,
    currentStreak: Math.max(currentStreak, tempStreak),
    bestStreak: Math.max(bestStreak, currentStreak),
    completionRateMonth,
    completionRateAllTime,
    strengthScore,
  };
}
