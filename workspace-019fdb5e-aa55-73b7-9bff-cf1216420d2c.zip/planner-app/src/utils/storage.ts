import type { DailyPlannerData } from '../types/planner';
import { getTodayJalali, getDateKey, formatPersianDateString } from './jalali';

export function createDefaultDayData(jy: number, jm: number, jd: number, dayName: string): DailyPlannerData {
  const dateKey = getDateKey(jy, jm, jd);
  const formattedDate = formatPersianDateString(jy, jm, jd);

  return {
    dateKey,
    selectedDayOfWeek: dayName,
    customDateText: formattedDate,
    daySubtitle: 'هر روز یک قدم جلوتر',
    mainFocus: '',
    quickNotes: '',
    waterGlasses: 0,
    priorities: [
      { id: 'p-1', text: '', completed: false },
      { id: 'p-2', text: '', completed: false },
      { id: 'p-3', text: '', completed: false },
      { id: 'p-4', text: '', completed: false },
      { id: 'p-5', text: '', completed: false },
    ],
    goals: [
      { id: 'g-1', text: '', completed: false },
      { id: 'g-2', text: '', completed: false },
      { id: 'g-3', text: '', completed: false },
      { id: 'g-4', text: '', completed: false },
    ],
    routines: [
      {
        id: 'r-reading',
        title: 'مطالعه',
        icon: 'book',
        completed: false,
        detail: '۲۰ تا ۳۰ صفحه کتاب تخصصی یا رشد فردی'
      },
      {
        id: 'r-growth',
        title: 'تسک رشد فردی',
        icon: 'play',
        completed: false,
        detail: 'مشاهده دوره آموزشی / پادکست عمیق'
      },
      {
        id: 'r-workout',
        title: 'تمرین / بدنسازی',
        icon: 'dumbbell',
        completed: false,
        detail: 'تمرینات قدرتی و کششی روزانه'
      }
    ],
    // 14 clean lined rows matching the image without hardcoded hours
    schedule: Array.from({ length: 14 }, (_, idx) => ({
      id: `s-${idx + 1}`,
      task: '',
      completed: false,
      category: idx < 3 ? 'routine' : idx < 8 ? 'work' : idx < 10 ? 'study' : 'personal'
    })),
    lessons: ['', '', '', ''],
  };
}

const STORAGE_PREFIX = 'ascent_planner_';

export function loadPlannerData(dateKey: string, fallback?: DailyPlannerData): DailyPlannerData {
  try {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}${dateKey}`);
    if (saved) {
      const parsed = JSON.parse(saved);
      const parts = dateKey.split('-');
      const defaultData = createDefaultDayData(
        parseInt(parts[0], 10) || 1405,
        parseInt(parts[1], 10) || 5,
        parseInt(parts[2], 10) || 17,
        parsed.selectedDayOfWeek || 'شنبه'
      );
      return {
        ...defaultData,
        ...parsed,
        dateKey
      };
    }
  } catch (e) {
    console.error('Error loading data from localStorage', e);
  }

  if (fallback) return fallback;

  const today = getTodayJalali();
  return createDefaultDayData(today.jy, today.jm, today.jd, today.dayName);
}

export function savePlannerData(data: DailyPlannerData): void {
  try {
    localStorage.setItem(`${STORAGE_PREFIX}${data.dateKey}`, JSON.stringify(data));
    const historyListStr = localStorage.getItem('ascent_planner_history_keys');
    const historyList: string[] = historyListStr ? JSON.parse(historyListStr) : [];
    if (!historyList.includes(data.dateKey)) {
      historyList.unshift(data.dateKey);
      localStorage.setItem('ascent_planner_history_keys', JSON.stringify(historyList.slice(0, 120)));
    }
  } catch (e) {
    console.error('Error saving data to localStorage', e);
  }
}

export function getAllSavedDates(): string[] {
  try {
    const historyListStr = localStorage.getItem('ascent_planner_history_keys');
    if (historyListStr) {
      return JSON.parse(historyListStr);
    }
  } catch (e) {
    console.error('Error fetching history', e);
  }
  return [];
}

export function checkDateHasData(dateKey: string): boolean {
  try {
    const saved = localStorage.getItem(`${STORAGE_PREFIX}${dateKey}`);
    if (saved) {
      const data = JSON.parse(saved);
      const hasPriorities = data.priorities?.some((p: any) => p.text?.trim() || p.completed);
      const hasSchedule = data.schedule?.some((s: any) => s.task?.trim() || s.completed);
      const hasGoals = data.goals?.some((g: any) => g.text?.trim() || g.completed);
      return hasPriorities || hasSchedule || hasGoals;
    }
  } catch {
    // ignore
  }
  return false;
}
