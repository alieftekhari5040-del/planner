#!/usr/bin/env bash
# 🚀 The Ascent Planner - Single Click Runner
cd "$(dirname "$0")/planner-app" || exit
echo "⚡ Starting The Ascent Planner on http://localhost:5173 ..."
npm run dev
